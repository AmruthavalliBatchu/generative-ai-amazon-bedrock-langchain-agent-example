"""DuckDuckGo Search API toolkit."""

from langchain.tools.ddg_search.tool import DuckDuckGoSearchRun

__all__ = ["DuckDuckGoSearchRun"]
